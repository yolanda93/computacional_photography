load('zeldas.mat');
load('rectangulo_maximo_negativo.mat');
rectangulo_maximo_negativo = rectangulo_maximo;
load('rectangulo_maximo_justado.mat');
load('orden_del_mosaico');
T = ordena(Q,P);

tamano_matrix = size(T);
NImag = tamano_matrix(2);

dx = -fix(min(rectangulo_maximo_negativo(:,1)));
dy = -fix(min(rectangulo_maximo_negativo(:,2)));
txy = [ 1 0 dx+5;
        0 1 dy+5;
        0 0 1];
    
for k=1:NImag
     T{k} = txy*T{k};
end

mosaico = zeros(10+fix(max(rectangulo_maximo(:,2))-min(rectangulo_maximo(:,2))), 10+fix(max(rectangulo_maximo(:,1))-min(rectangulo_maximo(:,1))),3);


Rx = [1 900 900 1]; Ry = [1 1 600 600];


for i=1:NImag,
    
    [N,M]=size(Rx);
    
    % Iniciamos el retangulo y lo rellenamos
    rectangulo = zeros(2*N,M)';
    for k=1:M,
            vertice = T{i}*[Rx(1,k); Ry(1,k);1];
            rectangulo(k,:)= [vertice(1),vertice(2)];
    end
    
    rx = fix(min(rectangulo(:,1))):fix(max(rectangulo(:,1)));
    ry = fix(min(rectangulo(:,2))):fix(max(rectangulo(:,2)));
    if i ~= 10
        nombre_imagen = sprintf('image0%d.jpg',i);
    else
        nombre_imagen = sprintf('image%d.jpg',i);
    end
    im = imread(nombre_imagen);
    im2 = interpola(im,inv(T{i}),rx,ry);
    %figure(1);image(im);
    %set(gcf, 'name', 'Imagen original');
    %figure(2);image(im2);
    %set(gcf, 'name', 'Imagen interpolada');
    
    %cogemos solo los datos que necesitamos y lo ponemos en una parte que
    % que "recortamos" previamente del mosaico
    mosaico_copia = mosaico(ry,rx,:);
    mosaico_copia(im2 > 0) = im2(im2 > 0);
    mosaico(ry,rx,:) = mosaico_copia;
    
    % Pasamos la imagen a 8bits para visualizarla
    mosaico = uint8(mosaico);
    figure(i);image(mosaico);
    set(gcf, 'name', 'Mosaico');
    set(gca,'Ydir','reverse');
    
    % Pintamos el borde de la nueva imagen
    p=patch(rectangulo(:,1),rectangulo(:,2),'w');
    set(p,'FaceColor','none','EdgeColor','r','LineWidth',2);
end

figure(11);image(mosaico);
set(gcf, 'name', 'Mosaico ya construido');
fc_truesize();