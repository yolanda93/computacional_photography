function err=error_ajuste(xy1,xy2,P)
% Tumbamos la matriz y a�adimos una columna de unos para poder
% multiplicarla con la matriz P
longitud = size(xy1);
err_2 = ([xy2'; ones(1,longitud(1))] - P*[xy1'; ones(1,longitud(1))])'; 
err = err_2(:,1:2);
end