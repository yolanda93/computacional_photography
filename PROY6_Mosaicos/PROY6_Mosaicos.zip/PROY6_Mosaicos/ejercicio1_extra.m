% im=imread('image01.jpg'); bw=fc_rgb2gray(im); imwrite(bw,'img.pgm');
% system('siftWin32 <img.pgm >data.txt');
% parse_keyfile('data.txt',[2,3]);
 name='fotos_propias/propia_0';
% Nfotos=6;
% s=cell(1,Nfotos);
% 
% for k = 1:Nfotos,
%     fich=sprintf('%s%02d.jpg',name,k);
%     im=imread(fich);
%     bw=fc_rgb2gray(im); 
%     imwrite(bw,'img.pgm');
%     system('siftWin32 <img.pgm >data.txt');
%     s{k}=parse_keyfile('data.txt',[2,3]);
% end

% save keypoints_propios s;

load('keypoints_propios.mat'); 

% [Q P]=find_QP(s);

% save zeldas_propio Q P;

load('zeldas_propio.mat');

T = ordena(Q,P);

Rx = [1 900 900 1]; Ry = [1 1 600 600];
tamano_matrix = size(Q);
tamano = tamano_matrix(2);
rectangulo_maximo = zeros(4,2);


for i=1:tamano,
    
    [N,M]=size(Rx);
    
    % Iniciamos el retangulo y lo rellenamos
    rectangulo = zeros(2*N,M)';
    for k=1:M,
            vertice = T{i}*[Rx(1,k); Ry(1,k);1];
            rectangulo(k,:)= [vertice(1),vertice(2)];
    end
    
    if max(rectangulo(:,1)) > max(rectangulo_maximo(:,1))
        rectangulo_maximo(1:2,1) = max(rectangulo(:,1));
    end
    if min(rectangulo(:,1)) < min(rectangulo_maximo(:,1))
        rectangulo_maximo(3:4,1) = min(rectangulo(:,1));
    end
    if max(rectangulo(:,2)) > max(rectangulo_maximo(:,2))
        rectangulo_maximo(2:3,2) = max(rectangulo(:,2));
    end
    if min(rectangulo(:,2)) < min(rectangulo_maximo(:,2))
        rectangulo_maximo(1:3:4,2) = min(rectangulo(:,2));
    end
    
    p=patch(rectangulo(:,1),rectangulo(:,2),'w');
    set(p,'FaceColor','none','EdgeColor','r','LineWidth',2);
end
set(gca,'Ydir','reverse');

% % Dimensiones
 p=patch(rectangulo_maximo(:,1),rectangulo_maximo(:,2),'w');
 set(p,'FaceColor','none','EdgeColor','g','LineWidth',2);
% display(rectangulo_maximo);
% fprintf('Altura minima: %d Altura maxima: %d\n', fix(min(rectangulo_maximo(:,2))), fix(max(rectangulo_maximo(:,2))));
% fprintf('Anchura minima: %d Anchura maxima: %d\n\n', fix(min(rectangulo_maximo(:,1))), fix(max(rectangulo_maximo(:,1))));
% fprintf('Altura total: %d\n', fix(max(rectangulo_maximo(:,2))- min(rectangulo_maximo(:,2))));
% fprintf('Anchura total: %d\n\n', fix(max(rectangulo_maximo(:,1))- min(rectangulo_maximo(:,1))));
% fprintf('Dx: %0.5f\n', -fix(min(rectangulo_maximo(:,1))));
% fprintf('Dy: %0.5f\n', -fix(min(rectangulo_maximo(:,2))));
save rectangulo_maximo_negativo_propio rectangulo_maximo;

load('rectangulo_maximo_negativo_propio.mat');

tamano_matrix = size(T);
NImag = tamano_matrix(2);

dx = -fix(min(rectangulo_maximo(:,1)));
dy = -fix(min(rectangulo_maximo(:,2)));
txy = [ 1 0 dx+3;
        0 1 dy+3;
        0 0 1];
    
for k=1:NImag
     T{k} = txy*T{k};
end

mosaico = zeros(10+fix(max(rectangulo_maximo(:,2))-min(rectangulo_maximo(:,2))), 10+fix(max(rectangulo_maximo(:,1))-min(rectangulo_maximo(:,1))),3);


Rx = [1 900 900 1]; Ry = [1 1 600 600];


for i=1:NImag,
    
    [N,M]=size(Rx);
    
    % Iniciamos el retangulo y lo rellenamos
    rectangulo = zeros(2*N,M)';
    for k=1:M,
            vertice = T{i}*[Rx(1,k); Ry(1,k);1];
            rectangulo(k,:)= [vertice(1),vertice(2)];
    end
    
    rx = fix(min(rectangulo(:,1))):fix(max(rectangulo(:,1)));
    ry = fix(min(rectangulo(:,2))):fix(max(rectangulo(:,2)));

    fich=sprintf('%s%02d.jpg',name,i);
    
    im = imread(fich);
    im2 = interpola(im,inv(T{i}),rx,ry);
    %figure(1);image(im);
    %set(gcf, 'name', 'Imagen original');
    %figure(2);image(im2);
    %set(gcf, 'name', 'Imagen interpolada');
    
    %cogemos solo los datos que necesitamos y lo ponemos en una parte que
    % que "recortamos" previamente del mosaico
    mosaico_copia = mosaico(ry,rx,:);
    mosaico_copia(im2 > 0) = im2(im2 > 0);
    mosaico(ry,rx,:) = mosaico_copia;
    
    % Pasamos la imagen a 8bits para visualizarla
    mosaico = uint8(mosaico);
    figure(i);image(mosaico);
    set(gcf, 'name', 'Mosaico');
    set(gca,'Ydir','reverse');
    
    % Pintamos el borde de la nueva imagen
    p=patch(rectangulo(:,1),rectangulo(:,2),'w');
    set(p,'FaceColor','none','EdgeColor','r','LineWidth',2);
end

figure(11);image(mosaico);
set(gcf, 'name', 'Mosaico ya construido');
fc_truesize();

