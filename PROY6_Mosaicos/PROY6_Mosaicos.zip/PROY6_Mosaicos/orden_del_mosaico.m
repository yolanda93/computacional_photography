orden_mosaico = [ 2 0; 8 2; 9 8; 3 2; 7 3; 10 9; 1 9; 4 7; 5 4; 6 5];
save orden_del_mosaico orden_mosaico;