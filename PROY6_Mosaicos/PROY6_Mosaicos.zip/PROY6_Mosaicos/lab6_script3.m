P = get_P3(xy1,xy2);
error = error_ajuste(xy1,xy2,P);
[Valor, posicion] = max(error)

%xy2_prima = P*[xy1'; ones(1,length(xy1))];
%xy2_prima = xy2_prima(1:2,:);
%xy2_prima == xy2'
