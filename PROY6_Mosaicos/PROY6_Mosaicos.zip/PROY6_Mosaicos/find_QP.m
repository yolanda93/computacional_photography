function [Q P]=find_QP(s)

  Nfotos_matrix = size(s);
  Nfotos = Nfotos_matrix(2);
  Q = zeros(Nfotos);
  P = cell(Nfotos);

  for i=1:Nfotos
     for j=(i+1):Nfotos
       [xy1, xy2] = find_matches(s{i},s{j});
       tamano = size(xy1);
       if tamano(1) > 5
          [Nmax,T]=ransac_fun(xy1,xy2);
          if Nmax > 5
              Q(i,j) = Nmax;
              Q(j,i) = Nmax;
              P{i,j} = T;
              P{j,i} = inv(T);
              fprintf('Tenemos %d puntos entre las imagenes %d y %d\n',tamano(1),i,j);
              fprintf('Entre los cuales estan aceptados %d', Nmax);
          end
       end
     end
  end
end

