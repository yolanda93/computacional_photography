function [T, orden_colocacion]  = ordena(Q,P)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
Nfotos_matrix = size(Q);
Nfotos = Nfotos_matrix(1);

usadas = false(1,Nfotos);
orden_colocacion = [];
T = cell(1,Nfotos);
T{1} = eye(3);
% Hallamos las parejas de cada foto
relacion_imagenes(1:Nfotos) = sum(Q(:,1:Nfotos));


[Valor, num_ancla] = max(relacion_imagenes);
usadas(num_ancla) = true;
orden_colocacion(end + 1,:) = [num_ancla,0];
sig_img = num_ancla;
fprintf('Image %d es el ANCLA\n', num_ancla);

for k=1:Nfotos-1 % -1 porque ya tenemos el ancla
  columna_a_analizar = Q(:,sig_img);
  columna_a_analizar_reducida = columna_a_analizar(~usadas); % la tilde ~ se usa como negacion de valor logico
  
  maximo = max(columna_a_analizar_reducida);
  
  if maximo == 0
      tamano_matrix = size(columna_a_analizar(~usadas));
      tamano = tamano_matrix(1);
      n = 0;
      for n = 1:tamano
          columna_a_analizar = Q(:, orden_colocacion(end - tamano));
          columna_a_analizar_reducida = columna_a_analizar(~usadas);
          maximo = max(columna_a_analizar_reducida);
          if ~isempty(maximo) && maximo ~= 0
              break;
          end
      end
      
      if maximo == 0
          [maximo_relativo, pos_x] = max(relacion_imagenes(~usadas));
          [pos_x, sig_img] = find(relacion_imagenes == maximo_relativo);
          [Valor, img_anterior] = max(Q(:, sig_img));
          orden_colocacion(end + 1, :) = [sig_img(1), img_anterior];
      else
          [sig_img, pos_y] = find(columna_a_analizar == maximo);
          
          orden_colocacion(end + 1, :) = [sig_img(1), orden_colocacion(end-n,1)];
      end
   else
      [sig_img, pos_y] = find(columna_a_analizar == maximo);
      orden_colocacion(end + 1, :) = [sig_img(1), orden_colocacion(end,1)];
  end
  usadas(sig_img) = true;
  imagenes_disponibles = 1:Nfotos;
  imagenes_disponibles_usadas = sprintf('%d', imagenes_disponibles(usadas));
  fprintf('Image %d enlaza con %d. COLOCADAS: %s\n', orden_colocacion(end,1), orden_colocacion(end,2), imagenes_disponibles_usadas);
end
    for k = 2:Nfotos
      T{1,k} = P{orden_colocacion(k,2),orden_colocacion(k,1)};
    end
end
