function [xy1, xy2] = find_matches(s1,s2)
xy1 = [];
xy2 = [];

tamano_s1 = size(s1.desc);
tamano_s2 = size(s2.desc);

for num_desc_s1 = 1:tamano_s1(1)
  desc_s1 = s1.desc(num_desc_s1,:);
  %distancias = zeros(tamano_s2(1),1); 
  Dmin = norm(desc_s1 - s2.desc(1,:));
  PosMin = s2.xy(1,:);
  Dmin2 = norm(desc_s1 - s2.desc(1,:))*5;
  
  for num_desc_s2 = 1:tamano_s2(1)
      distancia = norm(desc_s1 - s2.desc(num_desc_s2,:));
      if Dmin > distancia
          Dmin2 = Dmin;
          Dmin = distancia;
          PosMin = s2.xy(num_desc_s2,:);
      else
          if Dmin2 > distancia
              Dmin2 = distancia;
          end
      end
  
  end
  
  if (Dmin2/Dmin) >= 3
      xy1(end + 1,:) =  s1.xy(num_desc_s1,:);
      xy2(end + 1,:) =  PosMin;
  end
end



% function [xy1,xy2]=find_matches(s1,s2)
% 
% 
% xy1=[]; xy2=[];
% 
% for k = 1:size(s1.xy,1)
% 
%    distancia = zeros(1,size(s2.desc,1));
%    for n = 1:size(s2.desc,1)
%      distancia(n) = norm((s1.desc(k,:)- s2.desc(n,:)));
%    end
%    [Dmin,M] = min(distancia,[],2);
%    Dmin
%    ratio=(Dmin(2)/Dmin(1));
%    
%    if(ratio>=5)
%       xy1(k) = s1{k}.xy(1,1:2);
%       xy2(k) = s2{k}.xy(M(1),1:2);
%    end     
% end