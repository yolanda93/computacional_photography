function im = interpola(im,P,rx,ry)
tamano_matrix_y = size(ry);
tamano_y = tamano_matrix_y(2);
tamano_matrix_x = size(rx);
tamano_x = tamano_matrix_x(2);

im=double(im); % Ahora deja las cosas como est�n

Xi = zeros(tamano_y,tamano_x);     
Yi = zeros(tamano_y,tamano_x);

for pos_y = 1:tamano_y, 
    for pos_x = 1:tamano_x,
      vec = [rx(pos_x) ry(pos_y) 1]'; % hallamos vector de coordenadas homog�neas.
      vec = P*vec; % aplicamos P al vector    
      Xi(pos_y,pos_x)= vec(1,1);
      Yi(pos_y,pos_x) = vec(2,1);
    end
end
  
im2(:,:,1) = interp2(im(:,:,1),Xi,Yi,'bilinear');
im2(:,:,2) = interp2(im(:,:,2),Xi,Yi,'bilinear');
im2(:,:,3) = interp2(im(:,:,3),Xi,Yi,'bilinear');

im = uint8(im2);

return

