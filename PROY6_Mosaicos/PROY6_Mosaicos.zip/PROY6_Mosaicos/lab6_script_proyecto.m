clear;
load('keypoints.mat');
%[xy1,xy2]= find_matches(s{1},s{2});
%P = get_P3(xy1,xy2);
%err=error_ajuste(xy1,xy2,P);
%xy2_ajustado = norm(xy2 - err);


%[Q P]=find_QP(s);
%tamano_matrix = size(s);
%tamano = tamano_matrix(2);
%relacion_imagenes = zeros(1,tamano);
%relacion_imagenes(1:tamano) = sum(Q(:,1:tamano));
%save zeldas Q P;

load('zeldas.mat');
[T, orden_colocacion] = ordena(Q,P);
