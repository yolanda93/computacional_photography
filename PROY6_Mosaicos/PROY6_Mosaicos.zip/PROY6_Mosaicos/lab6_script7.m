T = ordena(Q,P);

txy = [ 1 0 -fix(min(rectangulo_maximo(:,1)));
        0 1 -fix(min(rectangulo_maximo(:,2)));
        0 0 1];
    
for k=1:tamano
    T{k} = txy*T{k};
end

Rx = [1 900 900 1]; Ry = [1 1 600 600];
tamano_matrix = size(Q);
tamano = tamano_matrix(2);
rectangulo_maximo = zeros(4,2);


for i=1:tamano,
    
    [N,M]=size(Rx);
    
    % Iniciamos el retangulo y lo rellenamos
    rectangulo = zeros(2*N,M)';
    for k=1:M,
            vertice = T{i}*[Rx(1,k); Ry(1,k);1];
            rectangulo(k,:)= [vertice(1),vertice(2)];
    end
    
    if max(rectangulo(:,1)) > max(rectangulo_maximo(:,1))
        rectangulo_maximo(1:2,1) = max(rectangulo(:,1));
    end
    if min(rectangulo(:,1)) < min(rectangulo_maximo(:,1))
        rectangulo_maximo(3:4,1) = min(rectangulo(:,1));
    end
    if max(rectangulo(:,2)) > max(rectangulo_maximo(:,2))
        rectangulo_maximo(2:3,2) = max(rectangulo(:,2));
    end
    if min(rectangulo(:,2)) < min(rectangulo_maximo(:,2))
        rectangulo_maximo(1:3:4,2) = min(rectangulo(:,2));
    end
    
    p=patch(rectangulo(:,1),rectangulo(:,2),'w');
    set(p,'FaceColor','none','EdgeColor','r','LineWidth',2);
end
set(gca,'Ydir','reverse');

% % Dimensiones
 p=patch(rectangulo_maximo(:,1),rectangulo_maximo(:,2),'w');
 set(p,'FaceColor','none','EdgeColor','g','LineWidth',2);
% display(rectangulo_maximo);
% fprintf('Altura minima: %d Altura maxima: %d\n', fix(min(rectangulo_maximo(:,2))), fix(max(rectangulo_maximo(:,2))));
% fprintf('Anchura minima: %d Anchura maxima: %d\n\n', fix(min(rectangulo_maximo(:,1))), fix(max(rectangulo_maximo(:,1))));
% fprintf('Altura total: %d\n', fix(max(rectangulo_maximo(:,2))- min(rectangulo_maximo(:,2))));
% fprintf('Anchura total: %d\n\n', fix(max(rectangulo_maximo(:,1))- min(rectangulo_maximo(:,1))));
% fprintf('Dx: %0.5f\n', -fix(min(rectangulo_maximo(:,1))));
% fprintf('Dy: %0.5f\n', -fix(min(rectangulo_maximo(:,2))));
% save rectangulo_maximo_negativo rectangulo_maximo;
% save rectangulo_maximo_justado rectangulo_maximo;

txy = [ 1 0 -fix(min(rectangulo_maximo(:,1)));
        0 1 -fix(min(rectangulo_maximo(:,2)));
        0 0 1];
    
for k=1:tamano
    T{k} = txy*T{k};
end

