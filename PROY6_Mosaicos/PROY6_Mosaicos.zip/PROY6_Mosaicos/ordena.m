function T = ordena(Q,P)

Nimag_matrix = size(Q);
Nimag=Nimag_matrix(1);

% Buscamos el ancla, imagen que mas conexiones tenga con el resto
A = Q>0;
[M,ancla]=max(sum(A));
fprintf('Imagen %d es el ancla.\n',ancla)

% Vector de booleanos para llevar la cuenta
usadas = false(1,Nimag);
usadas(ancla)=true;

% La transformacion para la matriz ancla sera la matriz identidad
T{ancla}= eye(3);
fotos = 1:Nimag;

while not(all(usadas)),
    
    A = zeros(Nimag);
    for fila=1:Nimag,
        for colum=1:Nimag,
            if(usadas(fila) & ~usadas(colum))
                A(fila,colum)=Q(fila,colum);
            end
        end
    end

    [M,index]=max(A(:)); [fila,colum]=ind2sub(size(A),index);
    if usadas(fila(1))
        nueva_imagen=colum(1);
        ref_lista=fila(1);
    else
        nueva_imagen=fila(1);
        ref_lista=colum(1);
    end
    T{nueva_imagen}=P{nueva_imagen,ref_lista}*T{ref_lista};
    usadas(nueva_imagen)=true;
    
    colocadas = sprintf('%d',fotos(usadas));
    fprintf('Imagen %d enlaza con %d. COLOCADAS: %s.\n',nueva_imagen,ref_lista,colocadas);
end
