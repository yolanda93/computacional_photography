function [Nmax,T]=ransac_fun(xy1,xy2)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

num_parejas = size(xy1);
Nmax = 0; select = [];

for k = 1:500
    % Hallamos un numero aleatorio entre 1 y num_parejas
    indice1 = 1 + fix(rand(1)*num_parejas(1)-1);
    indice2 = 1 + fix(rand(1)*num_parejas(1)-1);
    indice3 = 1 + fix(rand(1)*num_parejas(1)-1);
    if (indice1 == indice2 || indice2 == indice3 || indice1 == indice3)
       continue; 
    end
    
    %Buscamos aleatoriamente tres puntos
    coordenada_xy1 = [xy1(indice1,:); xy1(indice2,:); xy1(indice3,:)]; 
    coordenada_xy2 = [xy2(indice1,:); xy2(indice2,:); xy2(indice3,:)];
   
    % Buscamos matriz de transformacion
    T = get_P3(coordenada_xy1, coordenada_xy2);
    err=error_ajuste(xy1,xy2,T);
    
    error_normalizado = zeros(1,num_parejas(1));
    for j = 1:num_parejas(1)-1
      error_normalizado(j) = norm(err(j,:));
    end
    % Si encontramos
    if (length(find(error_normalizado < 0.5)) > Nmax)
        Nmax = length(find(error_normalizado < 0.5));
        select = [indice1, indice2, indice3];
    end
end

coordenada_xy1 = [xy1(select(1),:); xy1(select(2),:); xy1(select(3),:)]; 
coordenada_xy2 = [xy2(select(1),:); xy2(select(2),:); xy2(select(3),:)];
T = get_P3(coordenada_xy1, coordenada_xy2);
%fprintf('Numero de parejas aceptadas: %d\n', Nmax);
%fprintf('Puntos escogidos:');
%display(coordenada_xy1);
%display(coordenada_xy2);



    
    
end

