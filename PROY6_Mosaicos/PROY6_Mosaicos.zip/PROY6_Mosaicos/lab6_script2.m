
for k = 2:10
[xy1, xy2] = find_matches(s{1},s{k});
fprintf('Hemos encontrado %d parejas de puntos entre la imagen 1 y la imagen %d\n',length(xy1),k);
end
